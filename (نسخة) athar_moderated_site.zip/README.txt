# موقع أَثَر — نسخة مع مراجعة المشرف

## الملفات
- `index.html`: واجهة الموقع ولوحة المشرف.
- `setup.sql`: جداول قاعدة البيانات وسياسات الوصول.

## مهم قبل التشغيل
هذه النسخة تستخدم Supabase كقاعدة بيانات ومصادقة. من دون إعداد Supabase ستظهر صور وأمثلة توضيحية فقط، ولن تُرسل الطلبات إلى الإنترنت.

## خطوات الإعداد
1. أنشئ مشروعًا في Supabase.
2. افتح SQL Editor، والصق محتوى `setup.sql` كاملًا ثم شغّله.
3. من Project Settings / API انسخ Project URL و anon/publishable key.
4. افتح `index.html` في Acode، وابحث عن:
   `PASTE_YOUR_SUPABASE_PROJECT_URL_HERE`
   و
   `PASTE_YOUR_SUPABASE_ANON_KEY_HERE`
   واستبدلهما بالقيم الحقيقية.
5. من Supabase Authentication أنشئ حسابًا للمشرف باستخدام بريد وكلمة مرور.
6. من Authentication > Users انسخ UUID لحساب المشرف.
7. في SQL Editor شغّل الأمر التالي بعد استبدال UUID:
   `insert into public.admins (user_id) values ('UUID-HERE');`
8. ارفع `index.html` إلى مستودع GitHub، وفَعّل Settings > Pages > Deploy from a branch، واختر الفرع `main` والمجلد `/(root)` ثم Save.

## طريقة العمل
- الزائر يرسل اقتراحًا، ويحفظ بحالة `pending`.
- الزائر لا يرى إلا السجلات التي حالتها `approved`.
- المشرف يسجل الدخول في قسم «لوحة المشرف»، ويرى الطلبات المعلقة، ثم يوافق أو يرفض.
- الموافقة تغيّر الحالة إلى `approved` فيظهر الاقتراح للزوار.

## ملاحظات أمان
- لا تضع كلمة مرور المشرف أو مفتاح `service_role` في HTML.
- سياسات Row Level Security في `setup.sql` هي التي تمنع الزائر من الموافقة على اقتراحه بنفسه.
- لا تنشر معلومات حساسة في بيانات المبادرات.
- قبل إطلاق عام، أضف CAPTCHA/حماية من الرسائل المزعجة، وآلية للإبلاغ عن المحتوى، وراجع قواعد الخصوصية.
- صور Unsplash والخطوط تحتاج اتصالًا بالإنترنت.
