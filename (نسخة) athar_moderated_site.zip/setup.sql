-- نفّذ هذا السكربت في Supabase > SQL Editor
create extension if not exists pgcrypto;

create table if not exists public.initiatives (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 3 and 90),
  category text not null check (category in ('تعليم','مساعدة','تطوع','تقنية')),
  city text,
  contact text,
  description text not null check (char_length(description) between 5 and 1200),
  image_url text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.initiatives enable row level security;
alter table public.admins enable row level security;

-- أي زائر يمكنه إرسال اقتراح جديد، لكن لا يمكنه جعله approved بنفسه.
drop policy if exists "public can submit pending initiatives" on public.initiatives;
create policy "public can submit pending initiatives"
on public.initiatives for insert to anon, authenticated
with check (status = 'pending');

-- الجميع يرى المبادرات المعتمدة فقط.
drop policy if exists "public can read approved initiatives" on public.initiatives;
create policy "public can read approved initiatives"
on public.initiatives for select to anon, authenticated
using (status = 'approved');

-- المشرف المسجل فقط يمكنه رؤية كل الطلبات وتعديل حالتها.
drop policy if exists "admins can read all initiatives" on public.initiatives;
create policy "admins can read all initiatives"
on public.initiatives for select to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()));

drop policy if exists "admins can update initiatives" on public.initiatives;
create policy "admins can update initiatives"
on public.initiatives for update to authenticated
using (exists (select 1 from public.admins a where a.user_id = auth.uid()))
with check (exists (select 1 from public.admins a where a.user_id = auth.uid()));

-- بعد إنشاء حساب المشرف في Authentication > Users، أضف user UUID الخاص به هنا:
-- insert into public.admins (user_id) values ('PUT-ADMIN-USER-UUID-HERE');

-- تنبيه: لا تشارك service_role key أبدًا في ملفات HTML أو JavaScript.
